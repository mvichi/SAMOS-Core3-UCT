import subprocess
from pathlib import Path
import calendar

# -----------------------------
# USER CONFIGURATION
# -----------------------------
YEARS  = [2026]
MONTHS = [1, 2]            # January, February
GRID   = "s6250"            # AMSR2 grid
VERSION = "v5.4"

BASE_URL_TEMPLATE = (
    "https://data.seaice.uni-bremen.de/"
    "amsr2/asi_daygrid_swath/{grid}/netcdf/{year}/"
)

OUTPUT_ROOT = Path("amsr2_nc")

# -----------------------------
# DOWNLOAD FUNCTION
# -----------------------------
def download_file(url, output_file):
    cmd = [
        "wget",
        "-q",
        "--show-progress",
        "-O", str(output_file),
        url
    ]
    result = subprocess.run(cmd)

    if result.returncode != 0:
        print(f"Failed: {output_file.name}")
        if output_file.exists():
            output_file.unlink()
    else:
        print(f"Saved: {output_file.name}")

# -----------------------------
# MAIN LOOP
# -----------------------------
for year in YEARS:
    for month in MONTHS:
        n_days = calendar.monthrange(year, month)[1]

        out_dir = OUTPUT_ROOT / GRID / str(year) / f"{month:02d}"
        out_dir.mkdir(parents=True, exist_ok=True)

        base_url = BASE_URL_TEMPLATE.format(
            grid=GRID,
            year=year
        )

        for day in range(1, n_days + 1):
            datestr = f"{year}{month:02d}{day:02d}"
            filename = f"asi-AMSR2-{GRID}-{datestr}-{VERSION}.nc"
            url = base_url + filename
            output_file = out_dir / filename

            if output_file.exists():
                print(f"Exists: {filename}")
                continue

            download_file(url, output_file)

print("Download complete.")
